# azad-latest-posts
Latest posts will be shown in this this plugin
